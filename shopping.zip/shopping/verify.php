<?php
$page = "Vertify";
include 'includes/session.php';
include 'includes/head.php';

if (!isset($_SESSION['pay'])) {
	header('location:' . ROOT_HOST);
} else {
	unset($_SESSION['pay']);
}
?>

<body>
	<?php include 'includes/header.php'; ?>

	<section id="advertisement">
		<div class="container">
			<img src="<?php echo ROOT_HOST ?>images/shop/advertisement.jpg" alt="" />
		</div>
	</section>

	<section id="form">
		<!--form-->
		<div class="container">
			<div class="row">
				<div class='alert alert-success' role='alert'>
					<p>
						Your purchase has been successfully registered. Your invoice number: <?php echo rand() ?>
					</p>
				</div>
			</div>
		</div>
	</section>
	<?php
	include 'includes/footer.php';
	include 'includes/scripts.php';
	?>
</body>

</html>