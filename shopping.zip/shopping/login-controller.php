<?php
include 'includes/session.php';

if (isset($_POST['login'])) {

    $email = $_POST['email'];
    $password = $_POST['password'];

    $result = $db->loginUser($email, $password);

    if ($result == -1) {
        $_SESSION['error'] = 'Password incorrect.';
    } elseif ($result == -2) {
        $_SESSION['error'] = 'User with this profile was not found.';
    } else {
        $_SESSION['user'] = $result;
    }
} else {
    $_SESSION['error'] = 'Input login credentails first';
}

header('location:' . ROOT_HOST  . 'login.php');
