<?php
$page = "Cart";
include 'includes/session.php';
include 'includes/head.php';

if (!isset($_SESSION['checkout'])) {
    header('location:' . ROOT_HOST);
} else {
    unset($_SESSION['checkout']);
}

if (!isset($_SESSION['user'])) {
    header('location:' . ROOT_HOST . 'login.php');
} else {
    $user_id = $_SESSION['user'];
}
?>

<body>
    <?php include 'includes/header.php'; ?>
    <section id="cart_items">
        <div class="container">
            <div class="breadcrumbs">
                <ol class="breadcrumb">
                    <li><a href="<?php echo ROOT_HOST ?>">Home</a></li>
                    <li class="active">Check out</li>
                </ol>
            </div>
            <!--/breadcrums-->
            <div class="review-payment">
                <h2>Review & Payment</h2>
            </div>

            <div class="table-responsive cart_info">
                <table class="table table-condensed">
                    <thead>
                        <tr class="cart_menu">
                            <td class="image">Item</td>
                            <td class="description"></td>
                            <td class="price">Price</td>
                            <td class="quantity">Quantity</td>
                            <td class="total">Total</td>
                            <td></td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $items = $db->getShoppingCart($user_id);
                        $sum = 0;
                        foreach ($items as $product) {

                            $sum += $product['amount'];
                            if (strlen($product['name']) > 30) {
                                $p_name = substr($product['name'], 0, 27) . "...";
                            } else {
                                $p_name = $product['name'];
                            }
                        ?>
                            <tr>
                                <td class="cart_product">
                                    <a href=""><img src="<?php echo ROOT_HOST ?>images/product-details/<?php echo $product['image']; ?>" alt=""></a>
                                </td>
                                <td class="cart_description">
                                    <h4><a href=""><?php echo $p_name; ?></a></h4>
                                    <p>Web ID:esp153 <?php echo $product['id'] ?></p>
                                </td>
                                <td class="cart_price">
                                    <p><?php echo $product['price'] . " €"; ?></p>
                                </td>
                                <td class="cart_price">
                                    <p><?php echo $product['quantity'] ?></p>
                                </td>
                                <td class="cart_total">
                                    <p class="cart_total_price"><?php echo $product['amount'] . " €"; ?></p>
                                </td>
                            </tr>
                        <?php
                        }
                        ?>
                        <tr>
                            <td colspan="4">&nbsp;</td>
                            <td colspan="2">
                                <table class="table table-condensed total-result">
                                    <tr>
                                        <td>Cart Sub Total</td>
                                        <td><?php echo $sum . " €"; ?></td>
                                    </tr>
                                    <tr class="shipping-cost">
                                        <td>Shipping Cost</td>
                                        <td>Free</td>
                                    </tr>
                                    <tr>
                                        <td>Total</td>
                                        <td><span><?php echo $sum . " €"; ?></span></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td>
                                            <form action="<?php echo ROOT_HOST ?>pay-controller.php" method="POST">
                                                <input type="hidden" name="pay" value="1">
                                                <button type="submit" class="btn btn-primary btn-pay">Pay</button>
                                            </form>
                                        </td>
                                    </tr>

                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
    <!--/#cart_items-->
    <?php
    include 'includes/footer.php';
    include 'includes/scripts.php';
    ?>
</body>

</html>