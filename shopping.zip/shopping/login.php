<?php
$page = "login";
include 'includes/session.php';
include 'includes/head.php';


if (isset($_SESSION['user'])) {
	header('location: /');
}
?>

<body>
    <?php include 'includes/header.php'; ?>

    <section id="form">
        <!--form-->
        <div class="container">
            <div class="row">
                <?php
				if (isset($_SESSION['error'])) {
					echo "<div class='alert alert-danger' role='alert'>" . $_SESSION['error'] . "</div>";
					unset($_SESSION['error']);
				}
				if (isset($_SESSION['success'])) {
					echo "<div class='alert alert-success' role='alert'>" . $_SESSION['success'] . "</div>";
					unset($_SESSION['success']);
				}
				?>
                <div class="col-sm-4 col-sm-offset-1">
                    <div class="login-form">
                        <!--login form-->
                        <h2>Login to your account</h2>
                        <form method="POST" action="<?php echo ROOT_HOST ?>login-controller.php">
                            <input type="email" placeholder="Email Address" name="email" required />
                            <input type="password" name="password" placeholder="Password" required />
                            <button type="submit" class="btn btn-default" name="login">Login</button>
                        </form>
                    </div>
                    <!--/login form-->
                </div>
                <div class="col-sm-1">
                    <h2 class="or">OR</h2>
                </div>
                <div class="col-sm-4">
                    <div class="signup-form">
                        <!--sign up form-->
                        <h2>New User Signup!</h2>
                        <form method="POST" action="<?php echo ROOT_HOST ?>register-controller.php">
                            <input type="text" name="firstname" placeholder="Firstname"
                                value="<?php echo (isset($_SESSION['lastname'])) ? $_SESSION['lastname'] : '' ?>"
                                required />
                            <input type="text" name="lastname" placeholder="Lastname"
                                value="<?php echo (isset($_SESSION['lastname'])) ? $_SESSION['lastname'] : '' ?>"
                                required />
                            <input type="email" name="email" placeholder="Email"
                                value="<?php echo (isset($_SESSION['email'])) ? $_SESSION['email'] : '' ?>" required />
                            <input type="password" name="password" placeholder="Password" required />
                            <input type="password" name="repassword" placeholder="Retype password" required />
                            <button type="submit" class="btn btn-default" name="signup">Signup</button>
                        </form>
                    </div>
                    <!--/sign up form-->
                </div>
            </div>
        </div>
    </section>
    <!--/form-->

    <?php
	include 'includes/footer.php';
	include 'includes/scripts.php';
	?>
</body>

</html>