<?php
$page = "Products";
include 'includes/session.php';
include 'includes/head.php';
?>

<body>
    <?php include 'includes/header.php'; ?>

    <section id="advertisement">
        <div class="container">
            <img src="<?php echo ROOT_HOST ?>images/shop/advertisement.jpg" alt="" />
        </div>
    </section>

    <section>
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <?php include 'includes/sidebar.php'; ?>
                </div>

                <div class="col-sm-9 padding-right">
                    <div class="features_items">
                        <!--features_items-->
                        <h2 class="title text-center">Features Items</h2>
                        <?php
                        if (isset($_GET['id']) && isset($_GET['slug'])) {
                            $items = $db->getProducts($_GET['id']);
                        } else {
                            $items = $db->getProducts();
                        }
                        foreach ($items as $product) {
                            $photos = $product['photos'];
                            $list_photo = explode(',', $photos);

                            if (strlen($product['name']) > 30) {
                                $p_name = substr($product['name'], 0, 27) . "...";
                            } else {
                                $p_name = $product['name'];
                            }
                        ?>

                            <div class="col-sm-4">
                                <div class="product-image-wrapper">
                                    <div class="single-products">
                                        <input class="cart_quantity" type="hidden" value="1" product="<?php echo $product['id'] ?>">
                                        <div class="productinfo text-center">
                                            <img src="<?php echo ROOT_HOST ?>images/product-details/<?php echo $list_photo[0]; ?>" alt="" />
                                            <h2><?php echo $product['price'] . " €"; ?></h2>
                                            <p><?php echo $p_name; ?></p>
                                            <a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
                                        </div>
                                        <div class="product-overlay">
                                            <div class="overlay-content">
                                                <img src="<?php echo ROOT_HOST ?>images/product-details/<?php echo $list_photo[1]; ?>" alt="" />
                                                <h2><?php echo $product['price'] . " €"; ?></h2>
                                                <p><?php echo $p_name; ?></p>
                                                <a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
                                            </div>
                                        </div>
                                        <?php if ($product['new'] == 1) { ?>
                                            <img src="images/home/new.png" class="new" alt="" />
                                        <?php }
                                        if ($product['sale'] == 1) { ?>
                                            <img src="images/home/sale.png" class="new" alt="" />
                                        <?php } ?>
                                    </div>
                                    <div class="choose">
                                        <ul class="nav nav-pills nav-justified">
                                            <li><a href="<?php echo ROOT_HOST ?>product/details.php?id=<?php echo $product['id'] . '&slug=' . $product['slug'] ?>"><i class="fa fa-plus-square"></i>View Details</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        <?php
                        }
                        ?>
                    </div>
                    <!--features_items-->
                </div>
            </div>
        </div>
    </section>

    <?php
    include 'includes/footer.php';
    include 'includes/scripts.php';
    ?>
</body>

</html>